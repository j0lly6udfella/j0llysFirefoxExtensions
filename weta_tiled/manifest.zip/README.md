# Themes: Animated

## What it does

Tiles a PNG imagein the browser header.

## What it shows

How to use "additional_backgrounds": in conjunction with "additional_backgrounds_alignment": and "additional_backgrounds_tiling": to place an image within the browser header and then tile it.
