# Themes: Animated

## What it does

Employs an PNG image as the Chrome compatible theme_frame image in a theme.

## What it shows

How to use the Chrome compatible keys in a theme's manifest.json file to make a theme available for Firefox and Chrome.
